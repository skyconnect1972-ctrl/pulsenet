# pulsenet-api

PulseNet backend API — standalone Express + TypeScript server, extracted
from the `pulsenet` monorepo (`artifacts/api-server` plus its workspace
library dependencies) so it can be deployed on its own to Railway, Render,
Fly.io, or a VPS/Docker host, independent of the admin dashboard and
customer portal frontends.

Covers: authentication (JWT + 2FA) for staff and a separate customer/portal
auth flow (OTP), the billing engine (invoices, plans, subscriptions),
subscription lifecycle (activation/suspension/renewal/expiry enforcement),
M-Pesa STK push + Daraja callback handling, SMS notifications (Texin
provider, with a no-op fallback and per-tenant override), customer and
admin REST APIs, the provisioning engine (PPPoE/Hotspot via MikroTik),
MikroTik/RouterOS integration, RADIUS AAA config + accounting routes, the
AI NOC backend (fault/anomaly/congestion detection, auto-remediation,
optional Claude-written incident narratives), vouchers, dashboard
summaries, and audit logging.

**Not included** (out of scope for this package, and not requested):
`artifacts/radius-server` — the separate long-running UDP RADIUS
authentication/accounting *listener* process (ports 1812/1813). This API
server's `/api/radius/*` routes manage RADIUS *configuration* (NAS clients,
secrets) that the listener process reads from the same database; the
listener itself is a distinct deployable with its own `package.json` in the
original monorepo and was not part of the three requested packages. If you
need it, it can be extracted the same way this package was (it depends on
the same `@workspace/db`, `@workspace/crypto`, `@workspace/mikrotik`,
`@workspace/radius` libraries, now vendored here under `src/workspace/`).

## What changed vs. the monorepo copy

1. **Workspace library packages vendored in as local source**, not npm
   packages — `@workspace/api-zod`, `@workspace/crypto`, `@workspace/db`,
   `@workspace/mikrotik`, and `@workspace/radius` are copied verbatim into
   `src/workspace/{api-zod,crypto,db,mikrotik,radius}/`. Nothing in their
   logic was changed. All `@workspace/*` imports across every file (both in
   `src/routes|services|lib|middlewares` and inside the vendored libraries
   themselves, since `@workspace/radius` and `@workspace/mikrotik` import
   `@workspace/db`/`@workspace/crypto`) were rewritten to a `@/workspace/*`
   path alias.
2. **`@/*` path alias** resolves to `./src/*`, configured in both
   `tsconfig.json` (`compilerOptions.paths`, for typechecking/editors) and
   `build.mjs` (esbuild's `alias` option, since esbuild does not read
   tsconfig `paths` itself — this was verified to resolve correctly during
   extraction).
3. **`drizzle.config.ts` and `manual-sql/`** (incremental hand-written SQL
   migrations layered on top of `drizzle-kit push`) were copied from
   `lib/db` to the project root, since this package now owns its own
   database tooling instead of sharing a sibling workspace package.
4. **`zod` was repinned from `^3.24.4` to `^4.4.0`.** The generated
   `@workspace/api-zod` code and several routes call `zod.email()`,
   `zod.uuid()`, and `zod.url()` as top-level functions — these are Zod v4
   APIs and do not exist on installed Zod v3.25.x (confirmed: `npm install`
   against the original `^3.24.4` range resolves to 3.25.76, which resulted
   in `import-is-undefined` warnings from esbuild and would have thrown
   `TypeError: zod.email is not a function` at runtime on `/api/auth/*`,
   `/api/tenants`, and the generated schemas). No original lockfile shipped
   with the source repo to confirm what was actually installed previously;
   `^4.4.0` is the version range that matches what the code actually calls.
   `drizzle-zod@0.8.3` (also used here) declares `zod: "^3.25.0 || ^4.0.0"`
   as a peer, so this is compatible. This is the one functional (not just
   structural) change made during extraction — everything else preserves
   the original code as-is.
5. **`package.json` / `build.mjs` / `Dockerfile`** are new, standalone
   equivalents of the monorepo originals (same esbuild bundling approach,
   same external-package allowlist for native/undbundleable deps, same
   pino-worker handling), with workspace-only dependencies (`@workspace/*`)
   removed since those are now vendored source rather than packages.
6. **`.npmrc`** sets `legacy-peer-deps=true`. The original repo used pnpm
   with `auto-install-peers=false` / `strict-peer-dependencies=false` (pnpm
   config keys, ignored by npm); without an npm equivalent, `npm install`
   fails with `ERESOLVE` on `esbuild-plugin-pino@2.3.3`'s peer range
   (`esbuild@>=0.25.0 <=0.25.8`) against the pinned `esbuild@0.27.3`. This
   mirrors the original repo's own laxness about that peer range, not a new
   risk introduced here.

Nothing in `src/routes`, `src/services`, `src/lib`, `src/middlewares`, or
any vendored library's logic was changed beyond the import-path rewrite and
the zod version fix above.

## Install, build, and smoke test (verified)

```bash
npm install
npm run build      # esbuild bundle -> dist/index.mjs (+ pino worker files)
npm run typecheck  # optional; see note below
npm start          # requires DATABASE_URL etc. — see below
```

Both `npm install` and `npm run build` were run end-to-end during
extraction and complete cleanly with zero warnings (after the zod v4 fix
above; before it, esbuild reported 5 `import-is-undefined` warnings on the
`zod.email()`/`zod.uuid()`/`zod.url()` call sites). The built server was
also smoke-tested by starting it with dummy env vars: it logs
`"Server listening"` and correctly attempts (and fails, since no Postgres
was reachable in the sandbox) a real database query rather than crashing on
import/bundling — confirming the bundle and its module graph are intact.

`npm run typecheck` surfaces pre-existing type errors unrelated to this
extraction — e.g. `drizzle-orm` `eq()`/`inArray()` overload mismatches in
`routes/noc.ts` and `routes/sessions.ts`, and a couple of `MikroTikResponse<T>`
cast mismatches in the provisioning services. These come from installing
current `drizzle-orm`/`drizzle-kit`/`node-routeros` patch versions absent an
original lockfile to pin against; they don't affect the esbuild bundle
(esbuild transpiles per-file and doesn't type-check) and predate this
extraction in the sense that they'd reproduce identically if you ran
`pnpm install` fresh against the original monorepo's loose `catalog:`
ranges today.

## Environment variables

See `.env.example` (copied from the original repo's root — it's already
scoped correctly to this server; the RADIUS_AUTH_PORT/ACCT_PORT/BIND_HOST
vars documented there are for the separate radius-server listener process
described above, not for this package, and are safe to leave unset).

Required at minimum to boot:

| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string. |
| `JWT_SECRET` | Long random secret for staff/customer JWTs. |
| `PORT` | Listen port (e.g. `3000`). |
| `CORS_ORIGINS` | Comma-separated allowed origins — must include your deployed `pulsenet-admin-vercel` and `pulsenet-customer-vercel` URLs. |
| `PROVISIONING_CREDENTIAL_KEY` | `openssl rand -base64 32` — encrypts router-side subscriber passwords and RADIUS secrets at rest. |

Required to enable specific features (app boots and runs without them, with
that feature degraded or disabled — see inline comments in `.env.example`):

| Variable | Enables |
|---|---|
| `MPESA_CONSUMER_KEY` / `MPESA_CONSUMER_SECRET` / `MPESA_SHORTCODE` / `MPESA_PASSKEY` / `MPESA_ENVIRONMENT` / `MPESA_CALLBACK_URL` | M-Pesa STK push + Daraja callbacks. `MPESA_CALLBACK_URL` must be a publicly reachable HTTPS URL — Safaricom cannot call back to localhost. |
| `SMS_PROVIDER` / `TEXIN_API_URL` / `TEXIN_API_KEY` / `TEXIN_API_SECRET` / `TEXIN_SENDER_ID` | SMS (OTP, activation/suspension/expiry notices). Runs with no provider configured — messages queue with a clear "not configured" status instead of vanishing. Per-tenant Texin credentials set from the admin dashboard's Settings take priority over these. |
| `ANTHROPIC_API_KEY` / `ANTHROPIC_NOC_MODEL` | LLM-written NOC root-cause narratives and incident reports. Without it, the NOC still fully detects and auto-remediates faults using deterministic rules. |

## Database setup

This package owns its own Drizzle schema/migrations (vendored from
`lib/db`):

```bash
# push schema changes directly (dev / first provisioning)
npm run db:push
# or, if push reports destructive changes you've reviewed and accept:
npm run db:push-force
```

`manual-sql/` contains hand-written, sequentially-numbered SQL migrations
(`0001`…`0008`) that were layered on top of `drizzle-kit push` in the
original repo for changes push couldn't express cleanly (e.g. backfills).
Apply them in order against your database before running the app for the
first time if you're not starting from an empty database — check each
file's contents, as they are idempotent-by-convention (`IF NOT EXISTS`
etc.) but you should still review them against your actual schema state.

## Deploying

### Railway / Render (Node buildpack)
- Build command: `npm install && npm run build`
- Start command: `npm start` (runs `node --enable-source-maps dist/index.mjs`)
- Add a PostgreSQL plugin/add-on and set `DATABASE_URL` from it.
- Set the remaining env vars from the tables above.

### Docker / VPS
```bash
docker build -t pulsenet-api .
docker run -p 3000:3000 --env-file .env pulsenet-api
```
The `Dockerfile` is a two-stage build (compiles with `esbuild` in a
`python3`/`make`/`g++`-equipped stage so `bcrypt`'s native addon can build
from source if no prebuilt binary matches your target platform, then copies
the pruned production `node_modules` + `dist/` into a slim runtime image)
and includes a `HEALTHCHECK` against `/api/healthz`. It was not build-tested
in this sandbox (no Docker daemon available here) — the `npm install` /
`npm run build` steps it runs were verified directly on the host, but please
run `docker build` yourself before relying on it in production.

### MikroTik / RADIUS connectivity
This server talks outbound to MikroTik routers over the RouterOS API (see
`src/workspace/mikrotik/client.ts`) — ensure your deployment host has
network access to your routers' management IPs/ports. RADIUS AAA
configuration is managed through this API's `/api/radius` routes, but actual
RADIUS authentication/accounting traffic is handled by the separate
radius-server process noted above (not part of this package).

## Known blockers / follow-ups

- No original `pnpm-lock.yaml` shipped with the source repo, so exact
  transitive dependency versions could not be reproduced; `package-lock.json`
  here was generated fresh. Run `npm audit` and pin further if your deploy
  target requires reproducible builds.
- `Dockerfile` build was not exercised in this sandbox (no Docker daemon) —
  validate it in your CI/deploy environment before first production use.
- The zod v3→v4 repin (see above) is the only behavior-affecting change made
  during extraction; everything else is a structural/import-path change.
